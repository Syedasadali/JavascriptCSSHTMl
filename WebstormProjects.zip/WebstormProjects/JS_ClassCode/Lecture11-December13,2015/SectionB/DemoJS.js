
//This displays current time in HH:MM format

/*
function tellTime()
{
       var current = new Date();
       var hours   = current.getHours();
       var minutes = current.getMinutes();
       document.write("Current time: " + (hours + ":" + minutes));
}
*/

var country = "Pakistan";
alert(country);
