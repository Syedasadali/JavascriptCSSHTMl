/**
 * Created by MTA on 7/13/2014.
 */

var stdCounter  = 0;
var students    = [];
function addStudent(){
   var std = {
    sNo     : ++stdCounter,
    name    : document.getElementById("txtName").value,
    age     : parseInt(document.getElementById("txtAge").value)
   };
    students.push(std);
    addStudentToDOM(std);
    //students[stdCounter - 1] = std;
    //console.log(std);
   /*std.name = "asdjasd";
    std['name'] = "asdjasd";
    var propName = "name";
    std[propName]
    std['name'] = "asdjasd";*/
}

function addStudentToDOM(obj){
    var tBody   = document.getElementById("stdList");
    var row     = document.createElement("tr");
    //var column  = document.createElement("td");
    var column     = "";
    //for(var i = 0; i < 3; i++){
    for(var i in obj){
        column = document.createElement("td");
        column.innerText = obj[i];
        //column.innerHTML = obj[i];
        row.appendChild(column);
    }
    tBody.appendChild(row);
}







