/**
 * Created by MTA on 7/13/2014.
 */

var stdCounter  = 0;
var students    = [];
function addStudent(){
    var name    = document.getElementById("txtName").value;
    var age     = parseInt(document.getElementById("txtAge").value);
    var std     = new Student(name, age);
    students.push(std);
    addStudentToDOM(std);
}

function addStudentToDOM(obj){
    var tBody   = document.getElementById("stdList");
    var row     = document.createElement("tr");
    var column       /*= document.createElement("td");
    column.innerText = obj.sNo;
    row.appendChild(column);

    column           = document.createElement("td");
    column.innerText = obj.name;
    row.appendChild(column);

    column           = document.createElement("td");
    column.innerText = obj.age;
    row.appendChild(column);*/
    for(var i in obj){
        //alert(i + " -- " + obj[i]);
        column = document.createElement("td");
        column.innerText = obj[i];
        row.appendChild(column);
    }
    tBody.appendChild(row);
}


function Student(stdName, stdAge){

    //var sNo  = ++stdCounter;
    this.sNo  = ++stdCounter;
    this.name = stdName;
    this.age  = stdAge;

}

//Student.prototype.Hello = "Hello";






